﻿namespace EnvyAndSpiteLoader
{
    public class LevelBase
    {
        public List<string>? Level;
    }
}